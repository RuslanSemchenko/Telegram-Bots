CHANNEL_LINK = 'https://t.me/end_software'

admin_id = 123

CHAT_LINK = 'https://t.me/end_software'

OWNER_LINK = 'https://t.me/end_software'

a1_LEVEL = 0.5

a2_LEVEL = 0.3

a3_LEVEL = 0.1

chats = [-1001588856204, -1001194378596, -1001552236635, -1001518513494]

BOT_TOKEN = '1930116953:AAG3-qvoGT60wewwtJcdRMYvS_fewAhaP20'