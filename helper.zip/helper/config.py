API_TOKEN = '5784578185:AAG8J6PhDuh4KOOZgfkOmbOjgUiTLQ-bIao' # токен от тлеграм бота
admin = 123 # id админа, тобиж твой (взять тут - t.me/userinfobot)