def main():
    return 23

main()
