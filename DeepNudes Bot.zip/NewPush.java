package com.example.a_push;

public class NewPush {
    public String push;

    public NewPush(String push) {
        this.push = push;
    }
}
