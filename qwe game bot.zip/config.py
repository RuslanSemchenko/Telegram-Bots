
tokens = ['',''] #  1 - @qwegamebot | 2 - @testbottttttttttttbotssetrobot
token = tokens[0]
QiwiP2P_token = ''

owner_id = 1887634547

full_bot_name = 'QWE'
bot_name = 'qwegamebot'
channel_name = 'qwechannel'
chat_name = 'qwe_chat_two'

start_money = 10000
donat_money = 0
cash_family = 5



owner = '<a href="https://t.me/end_soft">Хаешка</a>'
channel = '<a href="https://t.me/end_soft">QWE CHANNEL | Канал</a>'
chat = '<a href="https://t.me/end_soft">QWE | Игровой чат #1</a>'
chat2 = '<a href="https://t.me/end_soft">QWE | Игровой чат #2</a>'
chat_id = -1001789828191 #  @qwechat  -1001537031068 | QWE ADMIN CHAT  -1001535128629 | @qwe_chat_two -1001692908382
admin_chat_id = '-1001535128629'

