data = {
"token": "5355438480:AAGzVfZleeQB5BP_f_VrPAKT0jkZ4nw_RH4",
"text": "Cлито в @ready_code!"
}