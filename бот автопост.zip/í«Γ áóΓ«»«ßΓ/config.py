TOKEN = '1174363525:AAHa-4yrEp3El16mfw45ejq88lo-RNqIXrU' #Токен бота
admin = 1083734473 #Chat_id админа 1
db = 'db.db'