from .all_filters import IsPrivate, IsSubscribed, IsNotSubscribed

if __name__ == "filters":
    # dp.filters_factory.bind(is_admin)
    pass
