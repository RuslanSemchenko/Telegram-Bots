from .start import dp
from .crypto_mop import dp
from .for_worker import dp
from .admin import dp
from .echo import dp

__all__ = ['dp']