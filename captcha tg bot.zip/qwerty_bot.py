from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
import random
from aiogram.dispatcher import FSMContext
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from config import TOKEN, chat_id

from aiogram.dispatcher.filters.state import State, StatesGroup

bot = Bot(token=TOKEN)
dp = Dispatcher(bot, storage=MemoryStorage())


class States(StatesGroup):
    question1 = State()
    question2 = State()


@dp.message_handler(commands=['start'])
async def process_start_command(m: types.Message, state: FSMContext):
    num1 = random.randint(0, 100)
    num2 = random.randint(0, 100)
    await state.update_data(num1=num1, num2=num2)
    await m.reply(
        'Для входа в группу нужно решить 2 примера. После успешного их прохождения - вы получите ссылку на '
        f'группу.\nПример 1\n{num1} + {num2} = ?')
    await States.question1.set()


@dp.message_handler(state=States.question1)
async def answer_q1(m: types.Message, state: FSMContext):
    user_data = await state.get_data()
    num3 = user_data['num1'] + user_data['num2']
    num1 = random.randint(0, 100)
    num2 = random.randint(0, 100)
    if num3 == int(m.text):
        await state.update_data(num3=num1, num4=num2)
        await m.reply(f'Пример 2\n{num1} + {num2} = ?')
        await States.question2.set()
    else:
        await state.finish()
        await m.reply('Неверно!')


@dp.message_handler(state=States.question2)
async def answer_q2(m: types.Message, state: FSMContext):
    if m.text.isdigit():
        user_data = await state.get_data()
        num3 = user_data['num3'] + user_data['num4']
        if num3 == int(m.text):
            invite = await m.bot.create_chat_invite_link(chat_id, member_limit=1)
            await m.reply(f'✅ Задачи успешно пройдены.\nСсылка на чат после вступления'
                          f' будет аннулирована.{invite.invite_link}')
            await state.finish()
        else:
            await state.finish()
            await m.reply('Неверно!')
    else:
        await state.finish()
        await m.reply('Неверно!')

if __name__ == '__main__':
    executor.start_polling(dp)
