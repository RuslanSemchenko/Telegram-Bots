TOKEN = 'ТОКЕН'
chat_id = ЧАТ АЙДИ