host = 'localhost'
user = '*Ваше имя пользователя*'
password = '*Ваш пароль*'
db_name = 'imdb'

token = '*Ваш токен*'