import asyncio
from peewee import *
from aiogram.dispatcher import FSMContext
from aiogram import Bot, Dispatcher, executor, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

db = SqliteDatabase('perlovkabot.db')

class BaseModel(Model):
    class Meta:
        database = db

class Users(BaseModel):
    UID = BigIntegerField(unique=True)

    @classmethod
    def get_rows_count(cls):
        return len(cls.select())

    @classmethod
    def get_rows(cls):
        return cls.select()

    @classmethod
    def get_row(cls, UID):
        return cls.get(UID == UID)

    @classmethod
    def row_exists(cls, UID):
        query = cls().select().where(cls.UID == UID)
        return query.exists()

    @classmethod
    def create_row(cls, UID):
        user, created = cls.get_or_create(UID=UID)

db.create_tables([Users])

accounts = [{'photo_path': 'account1.jpg', 'brawlers': '63/65', 'brawlpass_level': '42'}, {'photo_path': 'account2.webp', 'brawlers': '48/65', 'brawlpass_level': '70'}]
channels = [{'url': 't.me/username', 'id': ''}]

gems = InlineKeyboardButton('💎 Гемы', callback_data='gems')
account = InlineKeyboardButton('⚔️ Аккаунт', callback_data='account')
shop = InlineKeyboardButton('🔥 Магазин', callback_data='shop')
start_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(gems, account).add(shop)

gems170 = InlineKeyboardButton('💎 170', callback_data='gems170')
gems360 = InlineKeyboardButton('💎 360', callback_data='gems360')
gems950 = InlineKeyboardButton('💎 950', callback_data='gems950')
back = InlineKeyboardButton('⬅️ Назад', callback_data='back')
gems_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(gems170, gems360, gems950).add(back)

back1 = InlineKeyboardButton('⬅️ Назад', callback_data='back')
gogems = InlineKeyboardButton('Начать ✅', callback_data='gogems')
gogems_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(back1, gogems)

back1 = InlineKeyboardButton('⬅️ Назад', callback_data='back')
completed = InlineKeyboardButton('Выполнил ✅', callback_data='completed')
subscribed_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(back1, completed)

message = InlineKeyboardButton('Получить ➡️', callback_data='message')
message_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(message)

bio = InlineKeyboardButton('Переслал ✅', callback_data='bio')
bio_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(bio)

bio1 = InlineKeyboardButton('Получить ➡️', callback_data='bio1')
bio1_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(bio1)

end = InlineKeyboardButton('Выполнил 🥳✅', callback_data='end')
end_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(end)

loose = InlineKeyboardButton('Начать заново 🔄', callback_data='back')
loose_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(loose)

back = InlineKeyboardButton('⬅️ Назад', callback_data='back')
back_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(back)

mail = InlineKeyboardButton('📧 Рассылка', callback_data='mail')
dump = InlineKeyboardButton('🗄 Выгрузка БД', callback_data='dump')
admin_keyboard = InlineKeyboardMarkup(resize_keyboard=True).add(mail, dump)

aid = 5435788873
storage = MemoryStorage()
bot = Bot(token="ТОКЕН")
dp = Dispatcher(bot, storage=storage)

class FSMMail(StatesGroup):
    photo = State()
    description = State()

@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    if not Users.row_exists(message.from_user.id):
        Users.create_row(message.from_user.id)
        await bot.send_message(aid, f'Новый пользователь - {message.from_user.first_name} {message.from_user.last_name} (@{message.from_user.username} / {message.from_user.id})')

    await message.answer(f'''😎🌈👍 | Добро пожаловать,{message.from_user.first_name} ! Этот бот создан, для раздачи гемов и аккаунтов.

Выбери, что ты хочешь получить?''', reply_markup=start_keyboard)

@dp.message_handler(commands=['admin'])
async def admin(message: types.Message):
    if message.from_user.id == aid:
        await message.answer(f'''👮‍♂️ Админ-панель

Пользователей в боте: {Users.get_rows_count()}
Бот слит @end_soft''', reply_markup=admin_keyboard)

@dp.callback_query_handler(text='back')
async def _back(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    await callback_query.message.answer(f'''😎🌈👍 | Добро пожаловать,{callback_query.from_user.first_name} ! Этот бот создан, для раздачи гемов и аккаунтов.

Выбери, что ты хочешь получить?''', reply_markup=start_keyboard)

@dp.callback_query_handler(text='shop')
async def _shop(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    await callback_query.message.answer(f'''‼️ Не хотите ждать бесплатные гемы от нашего бота? Но вы тоже хотите купить Brawl Pass или гемы, но не знаете как и где? Тогда у меня хорошие новости, у нас свой личный магазин @end_soft, в котором вы можете задонатить себе на аккаунт - очень быстро, удобно, очень дёшево и надёжно💰
💳 Donat Holdik - @end_soft ‼️

💝💎 Гемы намного дешевле, чем у всех других ютуберов и донатеров! Также, там куча других разных игр, и частые скидки! 🤑🥳''', reply_markup=back_keyboard)

@dp.callback_query_handler(text='account')
async def _account(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    acc = accounts[1]#random.choice(accounts)
    await bot.send_photo(callback_query.from_user.id, open(acc['photo_path'], 'rb'), f'''💪 Бойцов: {acc["brawlers"]}
🎫 Куплен Brawl Pass ({acc["brawlpass_level"]} уровень)
✅ Доступна бесплатная смена ника
✅ Доступна перепривязка аккаунта''', reply_markup=gogems_keyboard)

@dp.callback_query_handler(text='gems')
async def _gems(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    await bot.send_photo(callback_query.from_user.id, open('gems.jpg', 'rb'), 'Выбери количество 👇', reply_markup=gems_keyboard)

@dp.callback_query_handler(text='gems170')
async def _gems170(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    await callback_query.message.answer('😍‼️ | Отлично, ты выбрал 170 гемов. Чтобы получить их — нужно выполнить всего 3 легких задания, на них уйдет не больше минуты!', reply_markup=gogems_keyboard)

@dp.callback_query_handler(text='gems360')
async def _gems360(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    await callback_query.message.answer('😍‼️ | Отлично, ты выбрал 360 гемов. Чтобы получить их — нужно выполнить всего 3 легких задания, на них уйдет не больше минуты!', reply_markup=gogems_keyboard)

@dp.callback_query_handler(text='gems950')
async def _gems950(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    await callback_query.message.answer('😍‼️ | Отлично, ты выбрал 950 гемов. Чтобы получить их — нужно выполнить всего 3 легких задания, на них уйдет не больше минуты!', reply_markup=gogems_keyboard)

@dp.callback_query_handler(text='gogems')
async def _gogems(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    text = ''
    for i, channel in enumerate(channels, start=1):
        text += f'⚡️ #{i} {channel["url"]}'
    await callback_query.message.answer(f'''📤 | ЗАДАНИЕ 1⃣:

👇 Подпишись НА ВСЕ каналы, ниже: 
{text}
* отписываться - нельзя!''', reply_markup=subscribed_keyboard)

@dp.callback_query_handler(text='completed')
async def _completed(callback_query: types.CallbackQuery):
    await callback_query.message.delete()
    for channel in channels:
        status = (await bot.get_chat_member(channel['id'], callback_query.from_user.id)).status

        if status not in ['creator', 'administrator', 'member']:
            await callback_query.message.answer('🤦‍♂❌ | Ты не полностью выполнил задание: нужно было на {len(channels)} канал/а.')
            await callback_query.message.answer('😎✅ | Выполни до конца!', reply_markup=loose_keyboard)
            return

    await callback_query.message.answer('''📤 | ЗАДАНИЕ 2⃣:

😎✅ | Перешли сообщение, которое я отправлю тебе ниже - 10 друзьям (только в Telegram). После нажатия на кнопку ниже, нужно будет подождать 2 минуты, которые бот дает на выполнение задания.''', reply_markup=message_keyboard)

@dp.callback_query_handler(text='message')
async def _message(callback_query: types.CallbackQuery):
    await callback_query.message.answer('''😱❤️‼️ Крутой бот, который раздает гемы и аккаунты, по Brawl Stars 👉 @end_soft

Не веришь? Проверь сам! ✅''')
    await asyncio.sleep(120)
    await callback_query.message.answer('🤔⁉️ | Переслал? Тогда осталось последнее, и самое легкое задание!', reply_markup=bio_keyboard)

@dp.callback_query_handler(text='bio')
async def _bio(callback_query: types.CallbackQuery):
    await callback_query.message.answer('''📤 | ПОСЛЕДНЕЕ ЗАДАНИЕ 3⃣:

😎✅ | Нужно скопировать новое сообщение, которое получишь ниже! Потом зайди в настройки своего профиля, и добавить его в свое описание (после нажатия на кнопку ниже, нужно будет подождать 2 минуты, которые бот дает на выполнение задания)''', reply_markup=bio1_keyboard)

@dp.callback_query_handler(text='bio1')
async def _bio1(callback_query: types.CallbackQuery):
    await callback_query.message.answer('😱❤️‼️ Крутой бот, который раздает гемы и аккаунты 👉 @end_soft')
    await asyncio.sleep(120)
    await callback_query.message.answer('🤔⁉️ | Добавил? Тогда жми кнопку ниже.', reply_markup=end_keyboard)

@dp.callback_query_handler(text='end')
async def _end(callback_query: types.CallbackQuery):
    await callback_query.message.answer('🤦‍♂❌ | Ты не полностью выполнил 2 задание: нужно было переслать именно 10ти людям, не меньше! Чем больше, тем лучше.')
    await callback_query.message.answer('😎✅ | Выполни до конца!', reply_markup=loose_keyboard)

@dp.callback_query_handler(text='dump')
async def _dump(callback_query: types.CallbackQuery):
    if callback_query.from_user.id == aid:
        await bot.send_document(callback_query.from_user.id, open('perlovkabot.db', 'rb'))

@dp.callback_query_handler(text='mail')
async def _mail(callback_query: types.CallbackQuery):
    if callback_query.from_user.id == aid:
        await FSMMail.photo.set()
        await callback_query.message.answer('📷 Загрузите фото рассылки\nДля пропуска напишите "-"')

@dp.message_handler(state=FSMMail.photo)
async def _mail2(message: types.Message, state: FSMContext):
    if message.from_user.id == aid:
        async with state.proxy() as data:
            try:
                data['photo'] = message.photo[0].file_id
            except:
                data['photo'] = None
        
        await FSMMail.next()
        await message.answer('✉️ Теперь введите текст рассылки\nПоддержка разметки "HTML"')

@dp.message_handler(state=FSMMail.description)
async def _mail3(message: types.Message, state: FSMContext):
    if message.from_user.id == aid:
        async with state.proxy() as data:
            data['description'] = message.text 

            g, e = 0, 0
            for user in Users.get_rows():
                try:
                    await bot.send_photo(user.UID, data['photo'], data['description'], parse_mode='html')
                    g += 1
                except:
                    try:
                        await bot.send_message(user.UID, data['description'], parse_mode='html')
                        g += 1
                    except:
                        e += 1

        await state.finish()
        await message.answer(f'⏱ Рассылка окончена!\n\n👍 Получили сообщение: {g}\n👎 Не получили: {e}', reply_markup=admin_keyboard)

if __name__ == '__main__':
    executor.start_polling(dp, skip_updates=True)