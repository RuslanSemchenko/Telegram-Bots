from .admin import vip
from .callback import vip
from .admin_sending import vip
from .admin_search import vip
from .admin_catalogs import vip
from .promocode import vip
class StorageQiwi:
    pass

__all__ = ["vip"]

