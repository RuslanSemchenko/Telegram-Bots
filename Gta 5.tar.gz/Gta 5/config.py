token = '54'
number_qiwi = '+79999999999' # С "+"
bot_name = 't8bot' #Введите название бота без @ (Пример: "bot_name = 'fakebotprodaja_bot'")
admin_id = 
support = "@sapportgay" # С "@"
