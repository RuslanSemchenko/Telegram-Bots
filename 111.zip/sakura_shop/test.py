a = {
    "b": 123
}

a['t'] = 321
print(a)