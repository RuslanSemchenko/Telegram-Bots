#cash token bot
cash_token = "5970072170:AAFQ6CiQrP-wiVOJP9dNFv0QHEDfYbM6-10"
#owner
cash_owner_name = ""
cash_owner_id = ""
cash_owner_username = ""
cash_owner_bio = ""


#admin list
cash_admin = ""
cash_admin2 = ""
cash_admin3 = ""
cash_admin4 = ""
cash_admin5 = ""
#start
startbot = "python das.py"
version = "1.1.3 version"
versionbot = version