const firstName = prompt('Введите имя ')
const lastName = prompt(firstName + ' Введите фамилию')
alert(firstName + lastName)