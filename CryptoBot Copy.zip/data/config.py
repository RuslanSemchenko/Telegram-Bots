from environs import Env

env = Env()

env.read_env()

BOT_TOKEN = env.str('BOT_TOKEN')
CRYPTO_PAY_TOKEN = env.str('CRYPTO_PAY_TOKEN')

photo_1 = 'AgACAgIAAxkBAAMFY1luFXUiUOtm6zHVAUYdH24Qoc4AArfDMRtRcclK_qRIOPpa4sgBAAMCAAN5AAMqBA'

ADMINS_ID = [5371593117, 1537002204]
