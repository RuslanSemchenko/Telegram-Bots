API_TOKEN = '1897079251:AAFwZjTdkKW120vnvFOtW32pckLdtdS6Wks' # токен от вашего бота в телеграме (взять тут t.me/botfather)
number = '996553330212' # номер киви кошелька
QIWI_SEC_TOKEN = 'eyJ2ZXJzaW9uIjoiUDJQIiwiZGF0YSI6eyJwYXlpbl9tZXJjaGFudF9zaXRlX3VpZCI6ImRqZHJraC0wMCIsInVzZXJfaWQiOiI5OTY1NTMzMzAyMTIiLCJzZWNyZXQiOiJkMDFhNjQ0ZjllZjdlMDVjMDU0NmVkOTU1YzdiZjVkMWZkZGY1MmZkZDJlN2M4Zjc2YmNkYTNlYjA0ZTQ3ZDNiIn19' # секретный ключ p2p https://p2p.qiwi.com
sum = 100 # сумма которую пользователь должен оплатить
admin = '1511796510' # id админа, узнать тут t.me/userinfobot#Бот слит в телеграм канале @END_SOFT
#Бот слит в телеграм канале @END_SOFT
#Бот слит в телеграм канале @END_SOFT