TOKEN = '5160745706:AAHFwMi-MqlmKRU7bDRj5ydzL6HMrTITb9Y'

WORDS = ['https://', 't.me', 'bot']


vibor = ['Выбери', 'выбери']

inform = ['Инфа', 'инфа']

sharik = ['Шар', 'шар']
